<?php

/**
 * Social Sharing Icons \ Activator
 * @link		http://www.oneall.com
 * @package 	oa_social_sharing_icons
 */

/* Social Sharing Activator */
class oa_social_sharing_icons_Activator
{
	/**
	 * Called when the plugin is activated.
	 */
	public static function activate ()
	{
	}
}
